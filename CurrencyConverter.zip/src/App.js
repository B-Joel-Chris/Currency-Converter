import './App.css';
import Converter from './components/converter';
import Header from './components/header';

function App() {
  return (
    <div className="App">
      <Header/>
        <Converter/>
    </div>
  );
}

export default App;
